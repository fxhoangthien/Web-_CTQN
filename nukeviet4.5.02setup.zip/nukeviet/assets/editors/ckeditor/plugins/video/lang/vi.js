﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('video', 'vi', {
		toolbar	: 'Video',
		dialogTitle : 'Cấu hình Video',
		fakeObject : 'Video',
		properties : 'Sửa video',
		widthRequired : 'Chiều rộng không được để trống',
		heightRequired : 'Chiều cao không được để trống',
		poster: 'Hình minh họa',
		sourceVideo: 'Nguồn video',
		sourceType : 'Loại Video',
		linkTemplate :  '<a href="%src%">%type%</a> ',
		fallbackTemplate : 'Your browser doesn\'t support video.<br>Please download the file: %links%'
});