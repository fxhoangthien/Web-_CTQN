<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:55 GMT
 */

$ranges=array(369098752=>array(372398271,'US'),372398272=>array(372398303,'AU'),372398304=>array(385875967,'US'));
